import React, { useEffect } from 'react';
import Lenis from 'lenis';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { AboutPhilosophy } from './components/AboutPhilosophy.tsx';
import { BentoModalities } from './components/BentoModalities.tsx';
import { AudienceSection } from './components/AudienceSection.tsx';
import { ExperienceSection } from './components/ExperienceSection.tsx';
import { LocationHours } from './components/LocationHours.tsx';
import { FaqAccordion } from './components/FaqAccordion.tsx';
import { CtaBanner } from './components/CtaBanner.tsx';
import { Footer } from './components/Footer.tsx';
import { FloatingWhatsApp } from './components/FloatingWhatsApp.tsx';

export default function App() {
  useEffect(() => {
    // Initialize Lenis for luxurious buttery-smooth scrolling (up and down)
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 0.9,
      touchMultiplier: 1.5,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    const rafId = requestAnimationFrame(raf);

    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F4EF] text-stone-900 selection:bg-stone-300 selection:text-stone-950">
      {/* Navigation */}
      <Navbar />

      {/* Main Flow Matching Base44 Video Reference */}
      <main className="flex-1">
        {/* 1. Hero */}
        <Hero />

        {/* 2. O Studio */}
        <AboutPhilosophy />

        {/* 3. As Modalidades */}
        <BentoModalities />

        {/* 4. Para Quem É */}
        <AudienceSection />

        {/* 5. A Experiência DK (Dark Full-Width Section) */}
        <ExperienceSection />

        {/* 6. Onde Estamos */}
        <LocationHours />

        {/* 7. Dúvidas */}
        <FaqAccordion />

        {/* 8. Seu Próximo Movimento (Sage Green Banner) */}
        <CtaBanner />
      </main>

      {/* 9. Minimal Footer */}
      <Footer />

      {/* WhatsApp Floating Access */}
      <FloatingWhatsApp />
    </div>
  );
}
