import React from 'react';
import { STUDIO_FACTS } from '../data/studioData.ts';
import { ScrollReveal } from './ScrollReveal.tsx';

export const CtaBanner: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-[#F6F4EF]">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12">
        <ScrollReveal className="relative bg-[#E8EDE6] rounded-3xl p-10 sm:p-16 md:p-20 overflow-hidden border border-[#DCE3D9]">
          {/* Giant Faint DK Monogram Watermark in Background */}
          <div className="absolute right-4 md:right-12 top-1/2 -translate-y-1/2 pointer-events-none select-none">
            <span className="font-serif text-[180px] sm:text-[240px] md:text-[320px] font-bold text-stone-900/[0.06] tracking-widest leading-none">
              DK
            </span>
          </div>

          <div className="relative z-10 max-w-2xl space-y-6">
            {/* Kicker */}
            <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 font-sans">
              SEU PRÓXIMO MOVIMENTO
            </div>

            {/* Headline */}
            <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold text-stone-950 leading-[1.12]">
              <span>Comece pelo</span>
              <br />
              <span>seu próximo movimento.</span>
            </h2>

            {/* Subtitle */}
            <p className="text-stone-700 text-base sm:text-lg leading-relaxed font-sans max-w-lg">
              Agende uma conversa com o DK Pilates Studio e descubra a melhor forma de começar.
            </p>

            {/* Action Button */}
            <div className="pt-2">
              <a
                href={STUDIO_FACTS.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-8 py-3.5 rounded-full text-xs font-medium tracking-wider text-white bg-stone-900 hover:bg-stone-800 hover:scale-[1.02] active:scale-[0.98] transition-all font-sans shadow-md"
              >
                Agendar pelo WhatsApp
              </a>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};
