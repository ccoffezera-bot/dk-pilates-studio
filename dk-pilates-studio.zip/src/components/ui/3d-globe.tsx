"use client";
import React, { useRef, useMemo, useState, useCallback, Suspense, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html } from "@react-three/drei";
import * as THREE from "three";
import { cn } from "@/src/lib/utils";

// Static texture assets for zero-latency, CORS-free loading
import defaultEarthDay from "../../assets/textures/earth-blue-marble.jpg";
import defaultEarthBump from "../../assets/textures/earth-topology.png";
import defaultEarthClouds from "../../assets/textures/earth-clouds.png";

// ============================================================================
// Types
// ============================================================================

export interface GlobeMarker {
  lat: number;
  lng: number;
  src?: string;
  label?: string;
  size?: number;
  sublabel?: string;
  isTarget?: boolean;
}

export interface Globe3DConfig {
  /** Globe radius */
  radius?: number;
  /** Globe base color (used as fallback or tint) */
  globeColor?: string;
  /** URL to the Earth texture map */
  textureUrl?: string;
  /** URL to the bump/elevation map for terrain */
  bumpMapUrl?: string;
  /** Whether to show atmosphere glow */
  showAtmosphere?: boolean;
  /** Atmosphere color */
  atmosphereColor?: string;
  /** Atmosphere intensity */
  atmosphereIntensity?: number;
  /** Atmosphere blur/softness (higher = more diffuse, default 3) */
  atmosphereBlur?: number;
  /** Terrain bump scale (0 = flat, higher = more pronounced) */
  bumpScale?: number;
  /** Auto rotate speed (0 = disabled) */
  autoRotateSpeed?: number;
  /** Enable user rotation via drag/touch (default true) */
  enableRotate?: boolean;
  /** Enable zoom */
  enableZoom?: boolean;
  /** Enable pan */
  enablePan?: boolean;
  /** Min zoom distance */
  minDistance?: number;
  /** Max zoom distance */
  maxDistance?: number;
  /** Initial rotation */
  initialRotation?: { x: number; y: number };
  /** Marker default size */
  markerSize?: number;
  /** Show wireframe overlay */
  showWireframe?: boolean;
  /** Wireframe color */
  wireframeColor?: string;
  /** Ambient light intensity */
  ambientIntensity?: number;
  /** Point light intensity */
  pointLightIntensity?: number;
  /** Background color (null for transparent) */
  backgroundColor?: string | null;
}

export interface Globe3DProps {
  /** Array of markers to display on the globe */
  markers?: GlobeMarker[];
  /** Globe configuration */
  config?: Globe3DConfig;
  /** Additional CSS classes */
  className?: string;
  /** Callback when a marker is clicked */
  onMarkerClick?: (marker: GlobeMarker) => void;
  /** Callback when a marker is hovered */
  onMarkerHover?: (marker: GlobeMarker | null) => void;
  /** Active zoomed marker to animate towards */
  zoomToMarker?: GlobeMarker | null;
}

// Convert Lat/Lng to Vector3 on sphere
export function latLngToVector3(lat: number, lng: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);

  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);

  return new THREE.Vector3(x, y, z);
}

// ============================================================================
// Atmospheric Glow Shader (Subtle, Clean Rim Glow on Light or Dark Backgrounds)
// ============================================================================

const AtmosphereGlowMaterial: React.FC<{
  radius: number;
  color?: string;
  intensity?: number;
}> = ({ radius, color = "#38bdf8", intensity = 0.6 }) => {
  const material = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        glowColor: { value: new THREE.Color(color) },
        intensity: { value: intensity },
      },
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        uniform vec3 glowColor;
        uniform float intensity;
        void main() {
          float rim = pow(1.0 - max(0.0, dot(vNormal, vec3(0.0, 0.0, 1.0))), 3.5);
          gl_FragColor = vec4(glowColor, rim * intensity);
        }
      `,
      side: THREE.BackSide,
      blending: THREE.NormalBlending,
      transparent: true,
      depthWrite: false,
    });
  }, [color, intensity]);

  return (
    <mesh>
      <sphereGeometry args={[radius * 1.04, 64, 64]} />
      <primitive object={material} attach="material" />
    </mesh>
  );
};

// ============================================================================
// Interactive Globe Marker Pin Component
// ============================================================================

interface MarkerPinProps {
  marker: GlobeMarker;
  radius: number;
  onClick: (m: GlobeMarker) => void;
  onHover: (m: GlobeMarker | null) => void;
  isHovered: boolean;
}

function GlobeMarkerPin({
  marker,
  radius,
  onClick,
  onHover,
  isHovered,
}: MarkerPinProps) {
  const position = useMemo(() => {
    return latLngToVector3(marker.lat, marker.lng, radius * 1.02);
  }, [marker.lat, marker.lng, radius]);

  const normal = useMemo(() => position.clone().normalize(), [position]);
  const rotation = useMemo(() => {
    const q = new THREE.Quaternion();
    q.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
    return new THREE.Euler().setFromQuaternion(q);
  }, [normal]);

  const handleTrigger = (e: any) => {
    e?.stopPropagation?.();
    onClick(marker);
  };

  const handlePointerEnter = (e: any) => {
    e?.stopPropagation?.();
    if (typeof document !== "undefined") {
      document.body.style.cursor = "pointer";
    }
    onHover(marker);
  };

  const handlePointerLeave = (e: any) => {
    e?.stopPropagation?.();
    if (typeof document !== "undefined") {
      document.body.style.cursor = "auto";
    }
    onHover(null);
  };

  return (
    <group position={position} rotation={rotation}>
      {/* Subtle glowing anchor disc */}
      <mesh
        position={[0, 0.015, 0]}
        onClick={handleTrigger}
        onPointerOver={handlePointerEnter}
        onPointerOut={handlePointerLeave}
      >
        <cylinderGeometry args={[0.07, 0.07, 0.015, 32]} />
        <meshBasicMaterial color="#f59e0b" transparent opacity={0.85} />
      </mesh>

      {/* Outer pulse wave */}
      <mesh
        position={[0, 0.02, 0]}
        onClick={handleTrigger}
        onPointerOver={handlePointerEnter}
        onPointerOut={handlePointerLeave}
      >
        <ringGeometry args={[0.07, 0.15, 32]} />
        <meshBasicMaterial
          color="#fbbf24"
          side={THREE.DoubleSide}
          transparent
          opacity={0.65}
        />
      </mesh>

      {/* Core Glowing Orb (the bolinha!) */}
      <mesh
        position={[0, 0.05, 0]}
        onClick={handleTrigger}
        onPointerOver={handlePointerEnter}
        onPointerOut={handlePointerLeave}
      >
        <sphereGeometry args={[0.055, 24, 24]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>

      {/* Interactive HTML Tooltip / Pin on the bolinha */}
      <Html
        position={[0, 0.14, 0]}
        center
        distanceFactor={5.8}
        zIndexRange={[100, 0]}
      >
        <div
          onClick={handleTrigger}
          onMouseEnter={handlePointerEnter}
          onMouseLeave={handlePointerLeave}
          className={cn(
            "cursor-pointer group flex flex-col items-center select-none transition-all duration-300 transform",
            isHovered ? "scale-110 -translate-y-1" : "scale-100"
          )}
          title="Clique na bolinha para voar até o estúdio"
        >
          {/* Beacon pulse ping indicator */}
          <div className="relative flex items-center justify-center">
            <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-amber-400 opacity-75 pointer-events-none" />
            <div className="relative px-3 py-1.5 rounded-full bg-stone-900/95 backdrop-blur-md text-white border border-amber-400/90 shadow-2xl flex items-center gap-2 cursor-pointer hover:bg-stone-900 hover:border-amber-300 transition-colors">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse shadow-sm shadow-amber-400" />
              <div className="flex flex-col text-left">
                <span className="text-[11px] font-bold tracking-wider uppercase text-amber-300 whitespace-nowrap">
                  {marker.label || "DK Pilates"}
                </span>
                {marker.sublabel && (
                  <span className="text-[9px] text-stone-300 font-medium whitespace-nowrap">
                    {marker.sublabel}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Tiny pointer triangle */}
          <div className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[6px] border-t-stone-900/95 -mt-[1px]" />
        </div>
      </Html>
    </group>
  );
}

// ============================================================================
// Inner Globe Scene (Realistic Earth + Clouds + Atmosphere + Flight Animation)
// ============================================================================

function GlobeScene({
  markers = [],
  config = {},
  onMarkerClick,
  onMarkerHover,
  zoomToMarker,
}: Globe3DProps) {
  const {
    radius = 1.25,
    globeColor = "#ffffff",
    autoRotateSpeed = 0.4,
    showAtmosphere = true,
    atmosphereColor = "#38bdf8",
    atmosphereIntensity = 0.9,
    showWireframe = false,
    wireframeColor = "transparent",
    ambientIntensity = 1.25,
    pointLightIntensity = 2.4,
    bumpScale = 0.08,
  } = config;

  const globeRef = useRef<THREE.Group>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  const controlsRef = useRef<any>(null);
  const [hoveredMarker, setHoveredMarker] = useState<GlobeMarker | null>(null);
  const { camera } = useThree();

  // Load NASA Blue Marble day texture, elevation bump map, and cloud layer
  const loader = useMemo(() => new THREE.TextureLoader(), []);

  const dayTexture = useMemo(() => {
    const url = config.textureUrl || defaultEarthDay;
    const tex = loader.load(url);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, [config.textureUrl, loader]);

  const bumpTexture = useMemo(() => {
    const url = config.bumpMapUrl || defaultEarthBump;
    return loader.load(url);
  }, [config.bumpMapUrl, loader]);

  const cloudsTexture = useMemo(() => {
    return loader.load(defaultEarthClouds);
  }, [loader]);

  // Set initial orientation so South America / São Paulo faces front
  useEffect(() => {
    if (globeRef.current) {
      globeRef.current.rotation.y = -0.55;
      globeRef.current.rotation.x = 0.28;
    }
  }, []);

  // Flight animation state
  const isFlying = useRef(false);
  const flightProgress = useRef(0);
  const flightTargetPos = useRef<THREE.Vector3 | null>(null);

  useEffect(() => {
    if (zoomToMarker) {
      isFlying.current = true;
      flightProgress.current = 0;
      // Coordinates of marker on sphere
      const targetVec = latLngToVector3(
        zoomToMarker.lat,
        zoomToMarker.lng,
        radius * 1.05
      );
      // Transform world position of marker based on globe rotation
      if (globeRef.current) {
        targetVec.applyEuler(globeRef.current.rotation);
      }
      flightTargetPos.current = targetVec
        .clone()
        .normalize()
        .multiplyScalar(radius * 1.30);
    } else {
      isFlying.current = false;
    }
  }, [zoomToMarker, radius]);

  useFrame((_state, delta) => {
    // Globe auto-rotation
    if (globeRef.current && !isFlying.current && autoRotateSpeed > 0) {
      globeRef.current.rotation.y += delta * 0.12 * autoRotateSpeed;
    }

    // Realistic independent cloud drift
    if (cloudsRef.current) {
      cloudsRef.current.rotation.y += delta * 0.02;
    }

    // Camera flight towards target marker
    if (isFlying.current && flightTargetPos.current) {
      flightProgress.current = Math.min(
        flightProgress.current + delta * 1.5,
        1.0
      );
      const ease = 0.5 - Math.cos(flightProgress.current * Math.PI) / 2;

      camera.position.lerp(flightTargetPos.current, 0.08 + ease * 0.1);
      camera.lookAt(0, 0, 0);

      if (controlsRef.current) {
        controlsRef.current.target.set(0, 0, 0);
        controlsRef.current.update();
      }
    }
  });

  const handleMarkerClick = useCallback(
    (m: GlobeMarker) => {
      onMarkerClick?.(m);
    },
    [onMarkerClick]
  );

  const handleMarkerHover = useCallback(
    (m: GlobeMarker | null) => {
      setHoveredMarker(m);
      onMarkerHover?.(m);
    },
    [onMarkerHover]
  );

  return (
    <>
      {/* Sunlight and Atmospheric Lighting */}
      <ambientLight intensity={ambientIntensity} />
      <directionalLight
        position={[12, 8, 10]}
        intensity={pointLightIntensity}
        color="#fff9ee"
      />
      <directionalLight
        position={[-12, -4, -8]}
        intensity={0.45}
        color="#38bdf8"
      />

      {/* Orbit Controls */}
      <OrbitControls
        ref={controlsRef}
        enabled={!isFlying.current}
        enableRotate={config.enableRotate ?? true}
        enableZoom={config.enableZoom ?? false}
        enablePan={config.enablePan ?? false}
        autoRotate={
          !isFlying.current &&
          (config.autoRotateSpeed ? config.autoRotateSpeed > 0 : true)
        }
        autoRotateSpeed={autoRotateSpeed}
        dampingFactor={0.06}
      />

      <group ref={globeRef}>
        {/* Main Photorealistic Earth Sphere (Blue Marble) */}
        <mesh>
          <sphereGeometry args={[radius, 64, 64]} />
          <meshStandardMaterial
            map={dayTexture}
            bumpMap={bumpTexture}
            bumpScale={bumpScale}
            roughness={0.65}
            metalness={0.12}
            color={globeColor}
          />
        </mesh>

        {/* Dynamic Atmospheric Clouds Layer */}
        <mesh ref={cloudsRef}>
          <sphereGeometry args={[radius * 1.012, 64, 64]} />
          <meshStandardMaterial
            map={cloudsTexture}
            transparent
            opacity={0.32}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>

        {/* Subtle Lat/Lon Coordinate Wireframe - disabled for clean photorealistic look */}
        {showWireframe && null}

        {/* Rayleigh Atmosphere Rim Glow */}
        {showAtmosphere && (
          <AtmosphereGlowMaterial
            radius={radius}
            color={atmosphereColor}
            intensity={atmosphereIntensity}
          />
        )}

        {/* Markers on Earth */}
        {markers.map((marker, idx) => (
          <GlobeMarkerPin
            key={idx}
            marker={marker}
            radius={radius}
            onClick={handleMarkerClick}
            onHover={handleMarkerHover}
            isHovered={hoveredMarker?.label === marker.label}
          />
        ))}
      </group>
    </>
  );
}

// ============================================================================
// Exported Globe3D Component
// ============================================================================

export function Globe3D({
  markers = [],
  config = {},
  className = "",
  onMarkerClick,
  onMarkerHover,
  zoomToMarker,
}: Globe3DProps) {
  return (
    <div
      className={cn(
        "relative w-full h-full overflow-hidden select-none bg-transparent",
        className
      )}
    >
      <Canvas
        camera={{ position: [0, 0, 5.2], fov: 38 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <GlobeScene
            markers={markers}
            config={config}
            onMarkerClick={onMarkerClick}
            onMarkerHover={onMarkerHover}
            zoomToMarker={zoomToMarker}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default Globe3D;
