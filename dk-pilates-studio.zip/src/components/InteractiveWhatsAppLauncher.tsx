import React, { useState } from 'react';
import { MessageCircle, ArrowUpRight, Check, Sparkles, Send } from 'lucide-react';
import { STUDIO_FACTS, QUICK_WHATSAPP_INTENTS } from '../data/studioData.ts';

export const InteractiveWhatsAppLauncher: React.FC = () => {
  const [selectedIntentId, setSelectedIntentId] = useState(QUICK_WHATSAPP_INTENTS[0].id);
  const [userName, setUserName] = useState('');
  const [userNote, setUserNote] = useState('');

  const currentIntent =
    QUICK_WHATSAPP_INTENTS.find((item) => item.id === selectedIntentId) ||
    QUICK_WHATSAPP_INTENTS[0];

  // Construct final WhatsApp message with optional visitor details
  const buildFinalMessage = () => {
    let msg = currentIntent.message;
    if (userName.trim()) {
      msg = `Olá! Meu nome é ${userName.trim()}. ` + msg.replace(/^Olá!\s*/, '');
    }
    if (userNote.trim()) {
      msg += ` (Observação: ${userNote.trim()})`;
    }
    return msg;
  };

  const finalMessage = buildFinalMessage();
  const whatsappLink = `${STUDIO_FACTS.whatsappUrl}?text=${encodeURIComponent(finalMessage)}`;

  return (
    <section id="contato-rapido" className="py-20 md:py-28 bg-[#F6F3EE] border-b border-stone-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest text-stone-600 font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-stone-800" />
            <span>Atendimento Personalizado</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-900 leading-[1.12]">
            Inicie sua conversa direta no WhatsApp oficial.
          </h2>
          <p className="text-stone-600 text-base sm:text-lg mt-4 font-sans leading-relaxed">
            Selecione o assunto do seu interesse abaixo para gerar uma mensagem pronta e falar diretamente com nossa equipe no Jardim São Paulo.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-stone-200/80 shadow-md p-6 sm:p-10">
          {/* Step 1: Objective Selector (Interactive Filter Tabs) */}
          <div className="mb-8">
            <label className="block text-xs uppercase tracking-wider font-semibold text-stone-500 mb-3">
              1. Qual é o seu principal objetivo?
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {QUICK_WHATSAPP_INTENTS.map((intent) => {
                const isSelected = intent.id === selectedIntentId;
                return (
                  <button
                    key={intent.id}
                    type="button"
                    onClick={() => setSelectedIntentId(intent.id)}
                    className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                        : 'border-stone-200 bg-stone-50/60 hover:bg-stone-100/80 text-stone-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold tracking-tight">
                        {intent.label}
                      </span>
                      {isSelected && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                    </div>
                    <p
                      className={`text-xs leading-relaxed ${
                        isSelected ? 'text-stone-300' : 'text-stone-500'
                      }`}
                    >
                      {intent.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Optional Info (Name / Note) */}
          <div className="mb-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="user-name" className="block text-xs uppercase tracking-wider font-semibold text-stone-500 mb-2">
                2. Seu nome (opcional)
              </label>
              <input
                id="user-name"
                type="text"
                placeholder="Ex: Mariana Silva"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-stone-200 bg-stone-50/40 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-stone-900 focus:bg-white transition-all"
              />
            </div>
            <div>
              <label htmlFor="user-note" className="block text-xs uppercase tracking-wider font-semibold text-stone-500 mb-2">
                Observação ou preferência (opcional)
              </label>
              <input
                id="user-note"
                type="text"
                placeholder="Ex: Prefiro horários de manhã cedo"
                value={userNote}
                onChange={(e) => setUserNote(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-stone-200 bg-stone-50/40 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-stone-900 focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Step 3: Message Preview & Action Button */}
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium mb-2">
              <span className="uppercase tracking-wider">Prévia da mensagem formatada:</span>
              <span className="font-mono text-[11px] text-stone-400">+55 11 97626-4452</span>
            </div>
            <div className="p-4 rounded-xl bg-white border border-stone-200 text-stone-800 text-sm font-sans leading-relaxed shadow-2xs mb-5">
              "{finalMessage}"
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-stone-500 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>Atendimento direto pelo WhatsApp comercial</span>
              </div>

              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-full text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 active:scale-[0.98] transition-all shadow-md group"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span>Iniciar Conversa no WhatsApp</span>
                <Send className="w-3.5 h-3.5 text-stone-400" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
