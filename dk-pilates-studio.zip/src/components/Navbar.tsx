import React, { useState, useEffect } from 'react';
import { Menu, X, Sparkles, Activity, Layers, Award, MapPin, Calendar } from 'lucide-react';
import { STUDIO_FACTS } from '../data/studioData.ts';
import { MenuBar, MenuItem } from '@/components/ui/glow-menu';
import { GlowButton } from '@/components/ui/glow-button';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeItem, setActiveItem] = useState<string>('Studio');

  const menuItems: MenuItem[] = [
    {
      label: 'Studio',
      href: '#studio',
      icon: Sparkles,
      gradient: 'via-amber-400/30 via-30% via-stone-300/30 via-60% via-amber-600/30 via-90%',
      iconColor: 'text-amber-600',
    },
    {
      label: 'Pilates',
      href: '#pilates',
      icon: Activity,
      gradient: 'via-rose-400/30 via-30% via-amber-300/30 via-60% via-stone-300/30 via-90%',
      iconColor: 'text-rose-600',
    },
    {
      label: 'Modalidades',
      href: '#modalidades',
      icon: Layers,
      gradient: 'via-emerald-400/30 via-30% via-teal-300/30 via-60% via-stone-300/30 via-90%',
      iconColor: 'text-emerald-600',
    },
    {
      label: 'Experiência',
      href: '#experiencia',
      icon: Award,
      gradient: 'via-indigo-400/30 via-30% via-purple-300/30 via-60% via-stone-300/30 via-90%',
      iconColor: 'text-indigo-600',
    },
    {
      label: 'Contato',
      href: '#contato',
      icon: MapPin,
      gradient: 'via-stone-400/30 via-30% via-amber-300/30 via-60% via-stone-500/30 via-90%',
      iconColor: 'text-stone-700',
    },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);

      // Detect current section in view
      const scrollPos = window.scrollY + 200;
      for (const item of menuItems) {
        const el = document.querySelector(item.href);
        if (el) {
          const rect = el.getBoundingClientRect();
          const top = rect.top + window.scrollY;
          const height = el.clientHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveItem(item.label);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleItemClick = (label: string) => {
    setActiveItem(label);
    const item = menuItems.find((i) => i.label === label);
    if (item) {
      setMobileMenuOpen(false);
      const target = document.querySelector(item.href);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#F6F3EE]/95 backdrop-blur-md border-b border-stone-200/80 shadow-2xs py-1.5'
          : 'bg-[#F6F3EE]/90 backdrop-blur-xs py-2 sm:py-2.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* Brand Wordmark (DK PILATES STUDIO) */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-[11px] sm:text-xs tracking-[0.22em] uppercase font-semibold text-stone-900 hover:text-stone-700 transition-colors font-sans whitespace-nowrap shrink-0"
          >
            DK PILATES STUDIO
          </a>

          {/* Center Glow MenuBar (Desktop / Tablet) */}
          <div className="hidden lg:flex items-center justify-center shrink-0">
            <MenuBar
              items={menuItems}
              activeItem={activeItem}
              onItemClick={handleItemClick}
              className="shadow-2xs"
            />
          </div>

          {/* Right Action Button with Glow & 3D Flip (Agendar aula) */}
          <div className="flex items-center gap-2 shrink-0">
            <GlowButton
              href={STUDIO_FACTS.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              icon={Calendar}
              iconColor="text-amber-400"
              size="sm"
              className="text-[10px] sm:text-[11px]"
            >
              Agendar
            </GlowButton>

            {/* Mobile Toggle */}
            <div className="flex lg:hidden items-center">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-xl text-stone-800 hover:text-stone-950 hover:bg-stone-200/50 focus:outline-hidden touch-manipulation"
                aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#F6F3EE] border-b border-stone-200 px-6 pt-3 pb-6 shadow-md mt-2">
          <nav className="flex flex-col space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = item.label === activeItem;
              return (
                <button
                  key={item.href}
                  type="button"
                  onClick={() => handleItemClick(item.label)}
                  className={`flex items-center gap-3 w-full text-left py-2.5 px-3 rounded-xl transition-all ${
                    isActive
                      ? 'bg-stone-900 text-white font-medium'
                      : 'text-stone-700 hover:bg-stone-200/60'
                  }`}
                >
                  <span className={isActive ? 'text-white' : item.iconColor}>
                    <Icon className="w-4 h-4" />
                  </span>
                  <span className="text-sm font-medium tracking-wide">{item.label}</span>
                </button>
              );
            })}
            <div className="pt-3">
              <GlowButton
                href={STUDIO_FACTS.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                icon={Calendar}
                iconColor="text-amber-400"
                className="w-full flex justify-center text-center"
              >
                Agendar aula
              </GlowButton>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
