import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Check, Sparkles } from 'lucide-react';
import cadillacApparatusImage from '../assets/images/pilates_cadillac_apparatus_1791497749258.jpg';

export const AudienceSection: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const isClickingRef = useRef(false);

  const audiences = [
    {
      id: 'Iniciantes',
      label: 'Iniciantes',
      tag: 'PRIMEIROS PASSOS',
      title: 'Aprenda os fundamentos com segurança e paciência',
      desc: 'Ideal para quem nunca praticou Pilates. Foco no alinhamento da coluna, respiração diafragmática consciente e domínio gradual dos aparelhos com suporte total.',
      bullets: [
        'Aulas no seu próprio ritmo e sem pressões',
        'Construção de consciência corporal e flexibilidade',
        'Acompanhamento individualizado em cada movimento',
      ],
    },
    {
      id: 'Fitness',
      label: 'Fitness',
      tag: 'ALTO RENDIMENTO',
      title: 'Força profunda, tônus e resistência sem impacto',
      desc: 'Para praticantes que buscam definição, fortalecimento intensivo do core (powerhouse) e estabilização articular sem agressão aos tendões ou joelhos.',
      bullets: [
        'Tonificação muscular global e equilíbrio postural',
        'Melhora comprovada no rendimento em corridas e esportes',
        'Definição do abdômen, glúteos e estabilidade lombar',
      ],
    },
    {
      id: 'Reabilitação',
      label: 'Reabilitação',
      tag: 'CUIDADO CLÍNICO',
      title: 'Alívio de dores na coluna e regeneração motora',
      desc: 'Abordagem terapêutica supervisionada para quem convive com hérnias de disco, desvios na coluna, lombalgias ou retorno seguro às atividades físicas.',
      bullets: [
        'Descompressão vertebral e alívio duradouro da tensão',
        'Fortalecimento preventivo e reeducação biomecânica',
        'Acompanhamento próximo com fisioterapeutas',
      ],
    },
    {
      id: 'Diferentes níveis',
      label: 'Diferentes níveis',
      tag: 'PROGRESSÃO REAL',
      title: 'Evolução contínua e sistematizada no Studio',
      desc: 'A metodologia se adapta a qualquer fase do aluno: do iniciante ao avançado, com sequências ricas no Reformer, Cadillac, Chair e Barrel.',
      bullets: [
        'Desafios graduais de equilíbrio e precisão',
        'Variações adaptadas para seus objetivos pessoais',
        'Sistematização que acompanha a sua evolução real',
      ],
    },
  ];

  // Precise scroll progression calculation:
  // - Fixed navbar is 64px (top-16).
  // - Sticky panel is locked at top: 64px, with height strictly bounded to calc(100dvh - 4rem).
  // - The 4 stages are mapped with a dedicated hold for stage 3:
  //     Stage 0 (Iniciantes):       0.00 <= progress < 0.23
  //     Stage 1 (Fitness):          0.23 <= progress < 0.46
  //     Stage 2 (Reabilitação):     0.46 <= progress < 0.69
  //     Stage 3 (Diferentes níveis): 0.69 <= progress <= 1.00
  // - Only when progress crosses 1.00 does the container reach its bottom and unpin,
  //   releasing naturally into ExperienceSection with ZERO premature overlap.
  useEffect(() => {
    const handleScroll = () => {
      if (isClickingRef.current || !containerRef.current || !stickyRef.current) return;

      const containerRect = containerRef.current.getBoundingClientRect();
      const stickyRect = stickyRef.current.getBoundingClientRect();

      const topOffset = 64; // Navbar fixed height (top-16)
      const stickyHeight = stickyRect.height;
      const runway = containerRect.height - stickyHeight;

      if (runway <= 0) return;

      const scrolledInPin = topOffset - containerRect.top;
      const progress = Math.max(0, Math.min(1, scrolledInPin / runway));

      let stage = 0;
      if (progress >= 0.69) {
        stage = 3;
      } else if (progress >= 0.46) {
        stage = 2;
      } else if (progress >= 0.23) {
        stage = 1;
      } else {
        stage = 0;
      }

      setActiveIndex(stage);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, []);

  const handleSelectTab = (index: number) => {
    setActiveIndex(index);
    if (!containerRef.current || !stickyRef.current) return;

    isClickingRef.current = true;
    const containerRect = containerRef.current.getBoundingClientRect();
    const stickyHeight = stickyRef.current.getBoundingClientRect().height;
    const runway = containerRect.height - stickyHeight;
    const containerTop = window.scrollY + containerRect.top;

    // Sweet spot targets for the 4 stages
    const stageTargets = [0.11, 0.34, 0.57, 0.82];
    const targetProgress = stageTargets[index];
    const topOffset = 64;
    const targetScroll = containerTop - topOffset + targetProgress * runway;

    window.scrollTo({
      top: targetScroll,
      behavior: 'smooth',
    });

    setTimeout(() => {
      isClickingRef.current = false;
    }, 500);
  };

  const activeAudience = audiences[activeIndex];

  return (
    <section
      id="pilates"
      ref={containerRef}
      className="relative z-20 bg-[#F6F3EE] border-t border-stone-200/60"
      style={{ height: '240vh' }}
    >
      {/* 
        Sticky viewport frame pinned directly below the 64px fixed navbar.
        Crucial: The height is strictly bounded to calc(100dvh - 4rem) and the inner
        elements are proportioned to fit comfortably within 420px of available space.
        This guarantees the panel NEVER scrolls up behind the header on any screen.
        Title, buttons, card, image and caption stay 100% frozen in place.
      */}
      <div
        ref={stickyRef}
        className="sticky top-16 z-20 w-full h-[calc(100dvh-4rem)] max-h-[calc(100dvh-4rem)] flex items-center justify-center bg-[#F6F3EE] px-4 sm:px-8 lg:px-12 py-2 sm:py-3 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-10 items-center">
            
            {/* Left Column: Heading, Text, Buttons, and Stable Card Frame */}
            <div className="lg:col-span-6 space-y-2">
              <div className="text-[10px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 font-sans">
                PARA QUEM É
              </div>

              {/* Exact Monumental Title - stays 100% fixed in view without moving */}
              <h2 className="font-serif text-xl sm:text-2xl md:text-3xl lg:text-[34px] xl:text-[38px] font-bold text-stone-950 leading-[1.1]">
                Inicie. Evolua. Encontre
                <br />
                seu ritmo.
              </h2>

              <p className="text-stone-600 text-xs sm:text-[13px] leading-snug font-sans max-w-lg">
                A apresentação pública do DK cita iniciantes, público fitness e reabilitação entre os públicos atendidos, com aulas personalizadas e sistematizadas.
              </p>

              {/* Navigation Pill Buttons - stay in the exact same place and highlight dynamically */}
              <div className="pt-0.5 flex flex-wrap gap-1.5 sm:gap-2">
                {audiences.map((aud, idx) => {
                  const isActive = activeIndex === idx;
                  return (
                    <button
                      key={aud.id}
                      type="button"
                      onClick={() => handleSelectTab(idx)}
                      className={`px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 cursor-pointer ${
                        isActive
                          ? 'bg-stone-900 text-white shadow-md scale-105 ring-2 ring-stone-900/10'
                          : 'bg-white text-stone-700 border border-stone-300 hover:border-stone-800'
                      }`}
                    >
                      {aud.label}
                    </button>
                  );
                })}
              </div>

              {/* 
                Stable Card Frame:
                The container box has a constant, fixed height and does not shift or collapse.
                Direct crossfade transition ensures no blank flash, no disappearing card,
                and NO text truncation (all bullets and descriptions are 100% visible).
              */}
              <div className="pt-0.5 w-full max-w-lg min-h-[180px] sm:min-h-[195px] lg:min-h-[210px]">
                <div className="w-full h-full p-3.5 sm:p-4 rounded-2xl bg-[#FAF8F5] border border-stone-300/80 shadow-md text-stone-800 font-sans flex flex-col justify-between">
                  <motion.div
                    key={activeAudience.id}
                    initial={{ opacity: 0.35, y: 3 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, ease: 'easeOut' }}
                    className="flex flex-col justify-between h-full"
                  >
                    <div>
                      {/* Top Accent Bar */}
                      <div className="w-10 h-1 bg-stone-900 rounded-full mb-1.5" />

                      {/* Tag Badge & Stage Indicator */}
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full flex items-center gap-1 font-mono">
                          <Sparkles className="w-3 h-3 text-amber-600" />
                          {activeAudience.tag}
                        </span>
                        <span className="text-[10px] font-semibold text-stone-400 font-sans uppercase tracking-wider">
                          0{activeIndex + 1} / 04
                        </span>
                      </div>

                      <h3 className="font-serif text-sm sm:text-base font-bold text-stone-950 leading-snug mb-1">
                        {activeAudience.title}
                      </h3>

                      <p className="text-stone-600 text-xs sm:text-[13px] leading-snug mb-2">
                        {activeAudience.desc}
                      </p>
                    </div>

                    {/* Bullets List - completely visible without truncation */}
                    <ul className="space-y-1 border-t border-stone-200/70 pt-1.5">
                      {activeAudience.bullets.map((bullet, i) => (
                        <li
                          key={i}
                          className="flex items-center gap-2 text-xs text-stone-800 font-medium"
                        >
                          <span className="w-3.5 h-3.5 rounded-full bg-stone-900 text-white flex items-center justify-center shrink-0">
                            <Check className="w-2 h-2 stroke-[3]" />
                          </span>
                          <span>{bullet}</span>
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                </div>
              </div>
            </div>

            {/* Right Column: Clean Large Photo Pinned in the exact same place */}
            <div className="lg:col-span-6 flex flex-col items-center lg:items-end space-y-1.5">
              <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl border border-stone-200/90 aspect-[16/10] sm:aspect-[4/3] w-full max-w-[440px] max-h-[180px] sm:max-h-[230px] lg:max-h-[260px] xl:max-h-[300px] bg-stone-100 group">
                <img
                  src={cadillacApparatusImage}
                  alt="Praticante realizando exercício guiado no aparelho Cadillac com alinhamento e precisão"
                  className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-102"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/25 via-transparent to-transparent pointer-events-none" />

                {/* Focus indicator badge synchronized with current content */}
                <div className="absolute bottom-2.5 sm:bottom-3 left-2.5 sm:left-3 z-10 px-3 py-1 rounded-full bg-stone-900/90 backdrop-blur-md text-white text-[10px] sm:text-[11px] font-medium tracking-wide flex items-center gap-1.5 border border-white/10 shadow-lg">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  <span>
                    Foco: <strong className="font-semibold text-white">{activeAudience.label}</strong>
                  </span>
                </div>
              </div>

              <p className="text-[10px] sm:text-[11px] text-stone-400 font-sans self-start lg:self-auto max-w-[440px]">
                Prática com equipamentos no Studio DK Pilates — precisão e biomecânica.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AudienceSection;
