import React from 'react';
import { STUDIO_FACTS } from '../data/studioData.ts';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#F6F4EF] py-10 border-t border-stone-200/80">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 font-sans">
          {/* Left */}
          <div>
            © {new Date().getFullYear()} DK Pilates Studio
          </div>

          {/* Center */}
          <div className="text-center">
            {STUDIO_FACTS.address.street} · São Paulo/SP
          </div>

          {/* Right */}
          <div>
            WhatsApp:{' '}
            <a
              href={STUDIO_FACTS.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-stone-700 hover:text-stone-950 font-medium transition-colors"
            >
              {STUDIO_FACTS.phone}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
