import React, { useRef } from 'react';
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from 'framer-motion';
import { ScrollReveal, StaggerContainer, StaggerItem } from './ScrollReveal.tsx';

export const FaqAccordion: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [openIndex, setOpenIndex] = React.useState<number | null>(0);

  const items = [
    {
      question: 'Preciso ter experiência?',
      answer:
        'Não é necessário assumir experiência prévia como requisito geral. O melhor é conversar com o studio sobre seu nível e objetivo.',
    },
    {
      question: 'O DK trabalha com diferentes públicos?',
      answer:
        'A descrição pública do studio cita iniciantes, público fitness e reabilitação.',
    },
    {
      question: 'Como agendar?',
      answer:
        'O caminho mais direto é falar com o studio pelo WhatsApp.',
    },
  ];

  // Automatically open each question sequentially as the user scrolls through the section
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start 65%', 'end 35%'],
  });

  useMotionValueEvent(scrollYProgress, 'change', (latest) => {
    const idx = Math.min(
      items.length - 1,
      Math.max(0, Math.floor(latest * items.length))
    );
    setOpenIndex(idx);
  });

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section
      ref={sectionRef}
      id="duvidas"
      className="py-20 md:py-28 bg-[#F6F4EF] border-t border-stone-200/60"
    >
      <div className="max-w-4xl mx-auto px-6 sm:px-10 lg:px-12">
        {/* Header */}
        <ScrollReveal className="mb-14 md:mb-18">
          <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 mb-4 font-sans">
            DÚVIDAS
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold text-stone-950 leading-[1.12]">
            Antes da sua primeira
            <br />
            aula.
          </h2>
        </ScrollReveal>

        {/* Minimal Accordion List */}
        <StaggerContainer className="divide-y divide-stone-200/80 border-y border-stone-200/80">
          {items.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <StaggerItem key={idx} className="py-5 sm:py-6">
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full flex items-center justify-between text-left group cursor-pointer focus:outline-hidden"
                  aria-expanded={isOpen}
                >
                  <span
                    className={`font-serif text-xl sm:text-2xl font-medium transition-colors ${
                      isOpen ? 'text-stone-950 font-semibold' : 'text-stone-800 group-hover:text-stone-950'
                    }`}
                  >
                    {item.question}
                  </span>
                  <span className="text-xl font-light text-stone-400 group-hover:text-stone-900 transition-colors ml-4 shrink-0 font-mono">
                    {isOpen ? '−' : '+'}
                  </span>
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: [0.21, 0.47, 0.32, 0.98] }}
                      className="overflow-hidden"
                    >
                      <p className="text-stone-600 font-sans text-sm sm:text-base leading-relaxed pt-3 pb-1 pr-6 max-w-2xl">
                        {item.answer}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </StaggerItem>
            );
          })}
        </StaggerContainer>
      </div>
    </section>
  );
};
