import React from 'react';
import FlowingMenu from './FlowingMenu.tsx';
import { ScrollReveal } from './ScrollReveal.tsx';
import studioInteriorImage from '../assets/images/studio_warm_interior_1791497758429.jpg';
import reformerMotionImage from '../assets/images/pilates_reformer_motion_1791497739323.jpg';
import cadillacApparatusImage from '../assets/images/pilates_cadillac_apparatus_1791497749258.jpg';
import heroStudioImage from '../assets/images/hero_pilates_studio_1791497728275.jpg';

export const ExperienceSection: React.FC = () => {
  const menuItems = [
    {
      text: 'Respire.',
      image: studioInteriorImage,
      isItalic: false,
    },
    {
      text: 'Controle.',
      image: reformerMotionImage,
      isItalic: true,
    },
    {
      text: 'Mova.',
      image: cadillacApparatusImage,
      isItalic: false,
    },
    {
      text: 'Evolua.',
      image: heroStudioImage,
      isItalic: true,
    },
  ];

  return (
    <section id="experiencia" className="relative z-10 py-16 md:py-24 bg-[#161616] text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Philosophy Description */}
          <ScrollReveal direction="left" className="lg:col-span-5 space-y-6">
            <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-400 font-sans">
              A EXPERIÊNCIA DK
            </div>

            <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl font-normal leading-[1.08] text-stone-100">
              Menos ruído,
              <br />
              <span className="italic font-light text-stone-300">mais presença.</span>
            </h2>

            <p className="text-stone-300 text-base sm:text-lg font-light leading-relaxed font-sans max-w-md">
              Uma linguagem visual inspirada na própria essência do Pilates: transições suaves, precisão anatômica e controle intencional em cada movimento.
            </p>

            <div className="pt-2">
              <span className="inline-flex items-center gap-2 text-xs text-stone-400 font-sans tracking-wider uppercase">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Ativação contínua ao rolar e passar o cursor
              </span>
            </div>
          </ScrollReveal>

          {/* Right Column: Interactive FlowingMenu */}
          <ScrollReveal direction="right" delay={0.15} className="lg:col-span-7">
            <div className="relative w-full h-[460px] sm:h-[500px] md:h-[540px] rounded-3xl overflow-hidden border border-white/10 bg-[#161616] shadow-2xl">
              <FlowingMenu
                items={menuItems}
                speed={14}
                bgColor="#161616"
                textColor="#F6F4EF"
                marqueeBgColor="#FAF8F5"
                marqueeTextColor="#161616"
                borderColor="rgba(255, 255, 255, 0.12)"
              />
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};
