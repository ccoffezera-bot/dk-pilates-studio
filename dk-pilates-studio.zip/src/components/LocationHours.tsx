import React from 'react';
import { STUDIO_FACTS } from '../data/studioData.ts';
import Globe3D from './ui/3d-globe';
import { MapPin, ExternalLink } from 'lucide-react';
import { ScrollReveal } from './ScrollReveal.tsx';
import CurvedLoop from './CurvedLoop.tsx';

export const LocationHours: React.FC = () => {
  return (
    <section id="contato" className="py-20 md:py-28 bg-[#F6F4EF] border-t border-stone-200/60 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: ONLY The 3D Earth Globe smoothly auto-rotating without markers or pins */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center w-full min-h-[360px] sm:min-h-[480px]">
            <div className="relative w-full h-[360px] sm:h-[480px] md:h-[540px] flex items-center justify-center pointer-events-none">
              <Globe3D
                markers={[]}
                config={{
                  radius: 1.25,
                  globeColor: "#ffffff",
                  autoRotateSpeed: 0.45,
                  enableRotate: false,
                  enableZoom: false,
                  enablePan: false,
                  atmosphereColor: "#38bdf8",
                  atmosphereIntensity: 0.6,
                  showWireframe: false,
                  bumpScale: 0.08,
                }}
                className="w-full h-full"
              />
            </div>
          </div>

          {/* Right Column: Information Table & Action (Span 6) */}
          <ScrollReveal direction="right" delay={0.15} className="lg:col-span-6 space-y-8">
            <div>
              <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 mb-4 font-sans">
                ONDE ESTAMOS
              </div>
              <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold text-stone-950 leading-[1.12]">
                No Jardim São Paulo,
                <br />
                perto do metrô.
              </h2>
              <p className="text-stone-600 font-sans text-base sm:text-lg mt-4 leading-relaxed">
                Localização privilegiada na Zona Norte de São Paulo, em rua tranquila e de fácil acesso, a apenas 400 metros da estação Jardim São Paulo - Ayrton Senna (Linha 1-Azul).
              </p>
            </div>

            {/* Editorial Information Table */}
            <div className="divide-y divide-stone-200/80 border-y border-stone-200/80 font-sans text-sm">
              <div className="py-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-stone-500 font-medium">Endereço</span>
                <span className="text-stone-900 font-medium flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-stone-600" />
                  Rua Gaspar Soares, 88 - Sala Pilates
                </span>
              </div>

              <div className="py-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-stone-500 font-medium">Região & Metrô</span>
                <span className="text-stone-900 font-medium">
                  Jardim São Paulo • 5 min a pé do Metrô
                </span>
              </div>

              <div className="py-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-stone-500 font-medium">Horários</span>
                <span className="text-stone-900 font-medium">
                  Seg a Sex: 06h às 22h • Sáb: 08h às 12h
                </span>
              </div>

              <div className="py-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-stone-500 font-medium">WhatsApp</span>
                <a
                  href={STUDIO_FACTS.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-stone-900 font-medium hover:underline flex items-center gap-1"
                >
                  (11) 97626-4452
                  <ExternalLink className="w-3.5 h-3.5 text-stone-500" />
                </a>
              </div>

              <div className="py-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-stone-500 font-medium">Convênios</span>
                <span className="text-stone-900 font-medium">
                  TotalPass • Gurupass • Wellhub
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <a
                href={STUDIO_FACTS.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-8 py-3.5 rounded-full text-xs font-medium tracking-wider text-white bg-stone-900 hover:bg-stone-800 transition-all font-sans shadow-lg hover:shadow-xl active:scale-95"
              >
                Falar no WhatsApp
              </a>

              <a
                href={STUDIO_FACTS.address.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-full text-xs font-medium tracking-wider text-stone-800 bg-white hover:bg-stone-100 border border-stone-300 transition-all font-sans shadow-sm"
              >
                Ver Rotas no Google Maps
              </a>
            </div>
          </ScrollReveal>
        </div>
      </div>

      {/* Straight Infinite Marquee Banner (CurvedLoop reto) */}
      <div className="mt-12 sm:mt-20 pt-6 border-t border-stone-200/70 overflow-hidden w-full bg-[#FAF8F5]/60">
        <CurvedLoop
          marqueeText="DK PILATES STUDIO ✦ MOVIMENTO COM PROPÓSITO ✦ FORÇA · CONTROLE · CONSCIÊNCIA ✦ A 400M DO METRÔ JARDIM SÃO PAULO ✦"
          speed={1.5}
          curveAmount={0}
          direction="left"
          interactive={true}
          className="fill-stone-900 font-serif text-[28px] sm:text-[44px] md:text-[58px] tracking-wider"
        />
      </div>
    </section>
  );
};
