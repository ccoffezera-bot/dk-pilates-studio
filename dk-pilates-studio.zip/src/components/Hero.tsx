import React from 'react';
import { motion } from 'framer-motion';
import { STUDIO_FACTS } from '../data/studioData.ts';
import reformerMotionImage from '../assets/images/pilates_reformer_motion_1791497739323.jpg';

export const Hero: React.FC = () => {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-28 overflow-hidden bg-[#F6F3EE]">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Column: Typography & CTAs (Span 7) */}
          <div className="lg:col-span-7 space-y-7 z-10">
            {/* Kicker */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 font-sans"
            >
              JARDIM SÃO PAULO · SÃO PAULO
            </motion.div>

            {/* Monumental Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="font-serif text-5xl sm:text-7xl md:text-8xl lg:text-[96px] xl:text-[104px] font-bold text-stone-950 leading-[0.95] sm:leading-[0.92] tracking-tight"
            >
              <span className="block">Movimento</span>
              <span className="block font-normal italic my-1 sm:my-2">com</span>
              <span className="block font-bold italic">propósito.</span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.22, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="text-stone-600 text-base sm:text-lg leading-relaxed max-w-lg font-sans pt-2"
            >
              Pilates personalizado para desenvolver força, controle, mobilidade e bem-estar — com atenção ao seu movimento.
            </motion.p>

            {/* Two Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.34, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="pt-2 flex flex-wrap items-center gap-3"
            >
              <a
                href={STUDIO_FACTS.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-full text-xs font-medium tracking-wider text-white bg-stone-900 hover:bg-stone-800 hover:scale-[1.02] active:scale-[0.98] transition-all font-sans shadow-xs"
              >
                Agendar uma aula
              </a>

              <a
                href="#studio"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-full text-xs font-medium tracking-wider text-stone-900 border border-stone-300 hover:border-stone-900 hover:bg-stone-200/50 hover:scale-[1.02] active:scale-[0.98] transition-all font-sans bg-transparent"
              >
                Conhecer o Studio
              </a>
            </motion.div>

            {/* Bottom address note */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.46 }}
              className="pt-6 text-xs text-stone-500 font-sans"
            >
              Rua Gaspar Soares, 88 · próximo ao Metrô Jardim São Paulo
            </motion.div>
          </div>

          {/* Right Column: Organic Oval Portal, Concentric Circles & Tilted Glass Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="lg:col-span-5 relative flex justify-center lg:justify-end"
          >
            {/* The Main Oval / Arched Portal */}
            <div className="relative w-full max-w-[420px] sm:max-w-[450px] aspect-[1/1.18] rounded-[220px] sm:rounded-[250px] overflow-hidden shadow-2xl bg-stone-200 border-[3px] border-white/80">
              {/* Photo */}
              <img
                src={reformerMotionImage}
                alt="Praticante realizando movimento no Reformer com postura e foco biomecânico"
                className="w-full h-full object-cover object-[52%_32%] scale-105"
              />

              {/* Fine White Concentric Geometric Circles Overlay */}
              <svg
                className="absolute inset-0 w-full h-full pointer-events-none"
                viewBox="0 0 450 530"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="245" cy="225" r="75" stroke="rgba(255, 255, 255, 0.45)" strokeWidth="1" />
                <circle cx="245" cy="225" r="130" stroke="rgba(255, 255, 255, 0.45)" strokeWidth="1" />
                <circle cx="245" cy="225" r="185" stroke="rgba(255, 255, 255, 0.45)" strokeWidth="1" />
                <circle cx="245" cy="225" r="240" stroke="rgba(255, 255, 255, 0.35)" strokeWidth="1" />
                <circle cx="245" cy="225" r="295" stroke="rgba(255, 255, 255, 0.25)" strokeWidth="1" />
              </svg>

              {/* Frosted Tilted Glass Card */}
              <div
                className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[82%] sm:w-[84%] aspect-[1.45/1] rounded-[28px] sm:rounded-[34px] rotate-[3.5deg] p-6 sm:p-7 flex flex-col justify-between shadow-xl"
                style={{
                  background: 'rgba(255, 255, 255, 0.48)',
                  backdropFilter: 'blur(16px)',
                  WebkitBackdropFilter: 'blur(16px)',
                  border: '1.2px solid rgba(255, 255, 255, 0.75)',
                  boxShadow: '0 20px 40px -12px rgba(0, 0, 0, 0.12), inset 0 1px 2px rgba(255, 255, 255, 0.9)',
                }}
              >
                <div className="flex-1 flex items-center justify-start pl-2">
                  <span
                    className="font-serif text-6xl sm:text-7xl md:text-[76px] font-normal text-white/95 tracking-wider select-none leading-none"
                    style={{
                      textShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
                    }}
                  >
                    DK
                  </span>
                </div>

                <div className="self-end pr-1">
                  <span className="text-[10px] sm:text-[11px] font-medium tracking-[0.26em] uppercase text-stone-800 font-sans">
                    PILATES STUDIO
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
