import React from 'react';
import { BorderGlow } from './BorderGlow.tsx';
import { ScrollReveal, StaggerContainer, StaggerItem } from './ScrollReveal.tsx';

export const AboutPhilosophy: React.FC = () => {
  return (
    <section id="studio" className="py-24 md:py-36 bg-[#F6F3EE] border-t border-stone-200/60">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-14">
        {/* Section Header */}
        <ScrollReveal className="max-w-3xl mb-16 md:mb-20">
          <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 mb-5 font-sans">
            O STUDIO
          </div>

          <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl font-bold text-stone-950 leading-[1.05] mb-6">
            <span>Seu corpo aprende</span>
            <br />
            <span className="font-normal italic">quando você presta</span>
            <br />
            <span>atenção.</span>
          </h2>

          <p className="text-stone-600 text-base sm:text-lg leading-relaxed font-sans max-w-2xl">
            Uma prática guiada por controle, precisão e consciência corporal. No DK Pilates Studio, as aulas são apresentadas como personalizadas e sistematizadas, para acompanhar diferentes níveis e objetivos.
          </p>
        </ScrollReveal>

        {/* 2 Feature Cards Side by Side with BorderGlow */}
        <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10">
          {/* Card 1: 01 · PRESENÇA */}
          <StaggerItem>
            <BorderGlow
              backgroundColor="#FAF8F5"
              borderRadius={20}
              glowColor="140 25 75"
              colors={['#b8c8bf', '#d8ded9', '#cfc8be']}
              glowRadius={35}
              glowIntensity={1.2}
              edgeSensitivity={30}
            >
              <div className="p-10 sm:p-12 h-full flex flex-col justify-between">
                <div className="text-[11px] font-semibold tracking-[0.2em] uppercase text-stone-400 mb-8 font-sans">
                  01 · PRESENÇA
                </div>
                <div>
                  <h3 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900 mb-4">
                    Acompanhamento próximo
                  </h3>
                  <p className="text-stone-600 text-base sm:text-lg leading-relaxed font-sans">
                    Um olhar atento para cada movimento, com uma experiência mais pessoal e intencional.
                  </p>
                </div>
              </div>
            </BorderGlow>
          </StaggerItem>

          {/* Card 2: 02 · MÉTODO */}
          <StaggerItem>
            <BorderGlow
              backgroundColor="#FAF8F5"
              borderRadius={20}
              glowColor="140 25 75"
              colors={['#b8c8bf', '#d8ded9', '#cfc8be']}
              glowRadius={35}
              glowIntensity={1.2}
              edgeSensitivity={30}
            >
              <div className="p-10 sm:p-12 h-full flex flex-col justify-between">
                <div className="text-[11px] font-semibold tracking-[0.2em] uppercase text-stone-400 mb-8 font-sans">
                  02 · MÉTODO
                </div>
                <div>
                  <h3 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900 mb-4">
                    Movimento consciente
                  </h3>
                  <p className="text-stone-600 text-base sm:text-lg leading-relaxed font-sans">
                    Força, mobilidade e controle se encontram em uma prática que valoriza a qualidade do movimento.
                  </p>
                </div>
              </div>
            </BorderGlow>
          </StaggerItem>
        </StaggerContainer>
      </div>
    </section>
  );
};
