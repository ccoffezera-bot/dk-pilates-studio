import React from 'react';
import { BorderGlow } from './BorderGlow.tsx';
import { ScrollReveal, StaggerContainer, StaggerItem } from './ScrollReveal.tsx';

export const BentoModalities: React.FC = () => {
  const modalities = [
    {
      number: '01',
      title: 'Pilates Clássico',
      discColor: 'from-[#CCD9D2] to-[#B8C8BF]',
      discBorder: '#A9BCB1',
      glowColor: '140 25 75',
      colors: ['#b8c8bf', '#d8ded9', '#a9bcb1'],
      description: 'A base tradicional do método, com foco em controle, alinhamento e consistência.',
    },
    {
      number: '02',
      title: 'Pilates Funcional',
      discColor: 'from-[#D2DDD6] to-[#C1CEC6]',
      discBorder: '#B2C2B8',
      glowColor: '150 20 75',
      colors: ['#c1cec6', '#d2ddd6', '#b2c2b8'],
      description: 'Uma abordagem que conecta movimento, estabilidade e preparo para a rotina.',
    },
    {
      number: '03',
      title: 'Pilates Studio',
      discColor: 'from-[#E3DDD4] to-[#D5CDC2]',
      discBorder: '#C6BCB0',
      glowColor: '35 25 75',
      colors: ['#d5cdc2', '#e3ddd4', '#c6bcb0'],
      description: 'Experiência com equipamentos e orientação mais próxima dentro do studio.',
    },
  ];

  return (
    <section id="modalidades" className="pt-16 pb-8 sm:pt-20 sm:pb-10 md:pt-28 md:pb-12 bg-[#F6F3EE] border-t border-stone-200/60">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-14">
        {/* Section Header */}
        <ScrollReveal className="max-w-3xl mb-16 md:mb-20">
          <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-stone-500 mb-5 font-sans">
            AS MODALIDADES
          </div>
          <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl font-bold text-stone-950 leading-[1.05]">
            Escolha a forma que faz sentido.
          </h2>
        </ScrollReveal>

        {/* 3 Column Grid with BorderGlow and staggered entrance */}
        <StaggerContainer className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10">
          {modalities.map((item, idx) => (
            <StaggerItem key={idx}>
              <BorderGlow
                backgroundColor="#FAF8F5"
                borderRadius={20}
                glowColor={item.glowColor}
                colors={item.colors}
                glowRadius={35}
                glowIntensity={1.2}
                edgeSensitivity={30}
                className="h-full"
              >
                <div className="p-8 sm:p-10 h-full flex flex-col justify-between group">
                  <div>
                    <div className="text-xs font-semibold text-stone-400 mb-3 font-mono">
                      {item.number}
                    </div>
                    <h3 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 mb-6">
                      {item.title}
                    </h3>

                    {/* Soft ceramic circular disc element */}
                    <div className="flex justify-center my-8 py-2">
                      <div className="relative w-36 h-36 rounded-full flex items-center justify-center">
                        <div
                          className={`w-32 h-32 rounded-full bg-gradient-to-br ${item.discColor} border border-[${item.discBorder}] transform group-hover:scale-105 transition-transform duration-500`}
                          style={{
                            boxShadow: 'inset 0 4px 12px rgba(255,255,255,0.6), 0 8px 24px rgba(0,0,0,0.06)',
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <p className="text-stone-600 text-sm sm:text-base leading-relaxed font-sans pt-4 border-t border-stone-200/50">
                    {item.description}
                  </p>
                </div>
              </BorderGlow>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
};
