export interface ModalityItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  benefits: string[];
  focusApparatus: string[];
  audience: string;
}

export interface ApparatusItem {
  id: string;
  name: string;
  role: string;
  description: string;
  focus: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export const STUDIO_FACTS = {
  name: "DK Pilates Studio",
  tagline: "Aulas personalizadas e sistematizadas que proporcionam saúde e bem-estar",
  phone: "(11) 97626-4452",
  phoneRaw: "+5511976264452",
  phoneTel: "tel:+5511976264452",
  instagramUrl: "https://www.instagram.com/dkpilates1/",
  instagramHandle: "@dkpilates1",
  facebookUrl: "https://www.facebook.com/dkpilates1/",
  address: {
    street: "R. Gaspar Soares, 88",
    neighborhood: "Santana",
    city: "São Paulo",
    state: "SP",
    cep: "02041-020",
    reference: "Dentro da academia Black Fitness Club, perto do metrô Jardim São Paulo",
    full: "R. Gaspar Soares, 88 — Santana, São Paulo — SP, CEP 02041-020",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=R.+Gaspar+Soares%2C+88+-+Santana%2C+S%C3%A3o+Paulo+-+SP%2C+02041-020",
  },
  scheduleNote: "Horários: [CONFIRMAR COM A EMPRESA]",
  passes: ["Wellhub (Gympass)", "TotalPass"],
  rating: {
    score: "5,0",
    source: "Wellhub",
    count: 12,
    date: "17/10/2026",
  },
  institutionalText:
    "Aqui no DK Studio contamos com profissionais capacitados e aulas personalizadas e sistematizadas, que proporcionam saúde e bem-estar para o seu corpo e a sua mente. Oferecemos uma experiência completa em treinamento físico integrado.",
  audience: "Todos os públicos a partir de 8 anos, público fitness e reabilitação",
  trialClassNote: "Aula experimental gratuita: segundo o Instagram do estúdio [CONFIRMAR COM A EMPRESA se continua valendo]",
  onlinePersonalNote: "Assessoria de personal online a partir de R$ 59,90, com treino grátis [CONFIRMAR COM A EMPRESA antes de exibir o valor]",
  amenitiesNote: "Comodidades no local (vestiário, chuveiro, armários etc. da academia Black Fitness Club) [CONFIRMAR COM A EMPRESA]",
};

export const MODALITIES: ModalityItem[] = [
  {
    id: "classico",
    title: "Pilates Clássico",
    subtitle: "A base tradicional do método nos grandes aparelhos",
    description:
      "Aulas no Reformer, Cadillac, Chair e Barrel com resistência de molas progressivas. Foco em alinhamento, respiração consciente, precisão e controle corporal para estruturar o corpo com segurança.",
    benefits: [
      "Fortalecimento profundo da musculatura estabilizadora (core)",
      "Descompressão vertebral e flexibilidade funcional",
      "Controle corporal refinado e consciência proprioceptiva",
    ],
    focusApparatus: ["Reformer", "Cadillac", "Wunda Chair", "Ladder Barrel"],
    audience: "Iniciantes e praticantes que buscam força, postura e bem-estar sem impacto.",
  },
  {
    id: "funcional",
    title: "Pilates Funcional",
    subtitle: "Biomecânica aplicada à rotina diária e rendimento",
    description:
      "Integração dos princípios do Pilates com sequências de movimentos multiplanares. Trabalha equilíbrio, coordenação e força em cadeias musculares completas para o dia a dia e suporte a esportes.",
    benefits: [
      "Agilidade, potência controlada e equilíbrio motor",
      "Resistência muscular e estabilização articular",
      "Melhora de rendimento e prevenção de sobrecargas",
    ],
    focusApparatus: ["Reformer", "Acessórios Funcionais", "Molas de Suspensão"],
    audience: "Público fitness e quem deseja dinamismo com suporte biomecânico seguro.",
  },
  {
    id: "studio",
    title: "Pilates Studio",
    subtitle: "Aulas personalizadas e sistematizadas com suporte próximo",
    description:
      "Experiência com acompanhamento individualizado dentro do studio, orientada para objetivos específicos: alívio de queixas articulares, saúde da coluna ou condicionamento progressivo.",
    benefits: [
      "Acompanhamento atento em cada execução e ajuste postural",
      "Progressão sistematizada de acordo com seu ritmo pessoal",
      "Alívio de dores nas costas e reeducação motora com segurança",
    ],
    focusApparatus: ["Cadillac", "Wunda Chair", "Ladder Barrel", "Reformer"],
    audience: "Todos os públicos a partir de 8 anos, reabilitação e praticantes de qualquer nível.",
  },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: "Quais públicos podem praticar no DK Pilates Studio?",
    answer:
      "Atendemos todos os públicos a partir de 8 anos, incluindo iniciantes que nunca praticaram, público fitness que busca fortalecimento intensivo e pessoas em reabilitação ou alívio de dores na coluna.",
  },
  {
    question: "O estúdio aceita convênios como Wellhub e TotalPass?",
    answer:
      "Sim. O DK Pilates Studio aceita Wellhub (Gympass) e TotalPass. Entre em contato pelo telefone (11) 97626-4452 para confirmar as modalidades e procedimentos de check-in.",
  },
  {
    question: "Existe aula experimental gratuita?",
    answer:
      "Segundo informações do Instagram oficial do estúdio (@dkpilates1), há menção a aula experimental gratuita [CONFIRMAR COM A EMPRESA se continua valendo]. Recomendamos ligar para (11) 97626-4452 para confirmar a disponibilidade atual.",
  },
  {
    question: "Quais são os horários de funcionamento do estúdio?",
    answer:
      "Horários: [CONFIRMAR COM A EMPRESA]. As informações públicas apresentam variações de turnos ao longo da semana; entre em contato diretamente pelo telefone (11) 97626-4452 para conferir os horários exatos de cada turma.",
  },
  {
    question: "Onde o estúdio está localizado?",
    answer:
      "Estamos localizados na R. Gaspar Soares, 88 — Santana, São Paulo — SP (CEP 02041-020), instalados dentro da academia Black Fitness Club, a poucos passos da estação de metrô Jardim São Paulo.",
  },
  {
    question: "O espaço conta com vestiários e comodidades?",
    answer:
      "Comodidades no local (vestiário, chuveiro, armários etc. da academia Black Fitness Club) [CONFIRMAR COM A EMPRESA].",
  },
];
