"use client";

import * as React from "react";
import { motion, type Variants, type Transition } from "framer-motion";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

export interface GlowButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  children: React.ReactNode;
  icon?: LucideIcon | React.ComponentType<{ className?: string }>;
  iconColor?: string;
  glowGradient?: string;
  className?: string;
  size?: "sm" | "md";
}

const itemVariants: Variants = {
  initial: { rotateX: 0, opacity: 1 },
  hover: { rotateX: -90, opacity: 0 },
};

const backVariants: Variants = {
  initial: { rotateX: 90, opacity: 0 },
  hover: { rotateX: 0, opacity: 1 },
};

const glowVariants: Variants = {
  initial: { opacity: 0, scale: 0.8 },
  hover: {
    opacity: 1,
    scale: 1.4,
    transition: {
      opacity: { duration: 0.35, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] },
      scale: { duration: 0.4, type: "spring", stiffness: 280, damping: 22 },
    },
  },
};

const outerAuraVariants: Variants = {
  initial: { opacity: 0 },
  hover: {
    opacity: 0.8,
    transition: {
      duration: 0.35,
      ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
    },
  },
};

const sharedTransition: Transition = {
  type: "spring",
  stiffness: 130,
  damping: 18,
  duration: 0.4,
};

export const GlowButton = React.forwardRef<HTMLAnchorElement, GlowButtonProps>(
  (
    {
      href,
      children,
      icon: Icon,
      iconColor = "text-amber-400",
      glowGradient = "bg-gradient-to-r from-amber-400/40 via-orange-400/30 to-amber-600/40 blur-md",
      className,
      size = "sm",
      ...props
    },
    ref,
  ) => {
    const isSm = size === "sm";

    return (
      <motion.a
        ref={ref}
        href={href}
        className={cn(
          "relative inline-block rounded-full p-[1px] select-none group focus:outline-hidden",
          className,
        )}
        initial="initial"
        whileHover="hover"
        style={{ perspective: "500px" }}
        {...(props as any)}
      >
        {/* Outer radial ambient glow aura */}
        <motion.div
          className="absolute -inset-1 rounded-full pointer-events-none bg-gradient-radial from-amber-400/25 via-orange-400/10 to-transparent blur-sm z-0"
          variants={outerAuraVariants}
        />

        {/* Dynamic expanding colored glow behind the button */}
        <motion.div
          className={cn(
            "absolute -inset-0.5 rounded-full pointer-events-none z-0",
            glowGradient,
          )}
          variants={glowVariants}
        />

        {/* Button body with 3D Flip Card */}
        <div className="relative z-10 block rounded-full overflow-hidden">
          {/* Front Face */}
          <motion.div
            className={cn(
              "flex items-center justify-center gap-1.5 rounded-full bg-stone-900 text-white border border-stone-800 shadow-xs transition-colors",
              isSm ? "px-3.5 py-1.5" : "px-4 sm:px-5 py-2",
            )}
            variants={itemVariants}
            transition={sharedTransition}
            style={{
              transformOrigin: "center bottom",
              transformStyle: "preserve-3d",
            }}
          >
            {Icon && (
              <span className={cn("transition-colors shrink-0", iconColor)}>
                <Icon className={isSm ? "h-3.5 w-3.5" : "h-4 w-4"} />
              </span>
            )}
            <span
              className={cn(
                "font-semibold tracking-wider uppercase whitespace-nowrap",
                isSm ? "text-[11px]" : "text-xs",
              )}
            >
              {children}
            </span>
          </motion.div>

          {/* Back Face (Flips into view on hover) */}
          <motion.div
            className={cn(
              "flex items-center justify-center gap-1.5 absolute inset-0 rounded-full bg-gradient-to-r from-amber-600 via-amber-700 to-stone-900 text-white border border-amber-400/40 shadow-xs",
              isSm ? "px-3.5 py-1.5" : "px-4 sm:px-5 py-2",
            )}
            variants={backVariants}
            transition={sharedTransition}
            style={{
              transformOrigin: "center top",
              transformStyle: "preserve-3d",
              rotateX: 90,
            }}
          >
            {Icon && (
              <span className="text-amber-200 shrink-0">
                <Icon className={isSm ? "h-3.5 w-3.5" : "h-4 w-4"} />
              </span>
            )}
            <span
              className={cn(
                "font-semibold tracking-wider uppercase text-white whitespace-nowrap",
                isSm ? "text-[11px]" : "text-xs",
              )}
            >
              {children}
            </span>
          </motion.div>
        </div>
      </motion.a>
    );
  },
);

GlowButton.displayName = "GlowButton";
