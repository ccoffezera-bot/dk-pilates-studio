"use client";

import * as React from "react";
import { motion, type Variants, type Transition } from "framer-motion";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

export interface MenuItem {
  icon: LucideIcon | React.ComponentType<{ className?: string }>;
  label: string;
  href: string;
  gradient: string;
  iconColor: string;
}

export interface MenuBarProps extends Omit<React.HTMLAttributes<HTMLElement>, "onAnimationStart" | "onDrag" | "onDragStart" | "onDragEnd"> {
  items: MenuItem[];
  activeItem?: string;
  onItemClick?: (label: string) => void;
}

const itemVariants: Variants = {
  initial: { rotateX: 0, opacity: 1 },
  hover: { rotateX: -90, opacity: 0 },
};

const backVariants: Variants = {
  initial: { rotateX: 90, opacity: 0 },
  hover: { rotateX: 0, opacity: 1 },
};

const glowVariants: Variants = {
  initial: { opacity: 0, scale: 0.8 },
  hover: {
    opacity: 1,
    scale: 1.4,
    transition: {
      opacity: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] },
      scale: { duration: 0.4, type: "spring", stiffness: 300, damping: 25 },
    },
  },
};

const navGlowVariants: Variants = {
  initial: { opacity: 0 },
  hover: {
    opacity: 0.8,
    transition: {
      duration: 0.4,
      ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
    },
  },
};

const sharedTransition: Transition = {
  type: "spring",
  stiffness: 120,
  damping: 20,
  duration: 0.4,
};

export const MenuBar = React.forwardRef<HTMLElement, MenuBarProps>(
  ({ className, items, activeItem, onItemClick, ...props }, ref) => {
    let isDarkTheme = false;
    try {
      const themeContext = useTheme();
      isDarkTheme = themeContext?.theme === "dark";
    } catch {
      isDarkTheme = false;
    }

    return (
      <motion.nav
        ref={ref}
        className={cn(
          "p-1 rounded-xl bg-white/80 dark:bg-stone-900/80 backdrop-blur-md border border-stone-200/70 dark:border-stone-800 shadow-2xs relative overflow-hidden",
          className,
        )}
        initial="initial"
        whileHover="hover"
        {...props}
      >
        <motion.div
          className={`absolute -inset-1 bg-gradient-radial from-transparent ${
            isDarkTheme
              ? "via-amber-400/25 via-30% via-stone-400/20 via-60% via-amber-600/25 via-90%"
              : "via-amber-400/15 via-30% via-stone-400/15 via-60% via-stone-600/15 via-90%"
          } to-transparent rounded-2xl z-0 pointer-events-none`}
          variants={navGlowVariants}
        />
        <ul className="flex items-center gap-0.5 sm:gap-1 relative z-10">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive = item.label === activeItem;

            return (
              <motion.li key={item.label} className="relative">
                <button
                  type="button"
                  onClick={() => onItemClick?.(item.label)}
                  className="block w-full focus:outline-hidden"
                >
                  <motion.div
                    className="block rounded-lg overflow-visible group relative select-none cursor-pointer"
                    style={{ perspective: "500px" }}
                    whileHover="hover"
                    initial="initial"
                  >
                    <motion.div
                      className={cn(
                        "absolute -inset-1 z-0 pointer-events-none opacity-0 rounded-xl",
                        item.gradient,
                      )}
                      variants={glowVariants}
                    />

                    {/* Front Face */}
                    <motion.div
                      className={cn(
                        "flex items-center gap-1.5 px-2.5 py-1.5 relative z-10 rounded-lg transition-all duration-200",
                        isActive
                          ? "bg-stone-900 text-white shadow-2xs font-medium"
                          : "text-stone-700 hover:text-stone-950 hover:bg-stone-100/70",
                      )}
                      variants={itemVariants}
                      transition={sharedTransition}
                      style={{ transformOrigin: "center bottom" }}
                    >
                      <span className={cn("transition-colors shrink-0", item.iconColor)}>
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <span className="text-[11px] sm:text-xs font-medium tracking-normal whitespace-nowrap">
                        {item.label}
                      </span>
                    </motion.div>

                    {/* Back Face (Flip rotation) */}
                    <motion.div
                      className={cn(
                        "flex items-center gap-1.5 px-2.5 py-1.5 absolute inset-0 z-10 rounded-lg transition-all duration-200",
                        isActive
                          ? "bg-stone-900 text-white shadow-2xs font-medium"
                          : "bg-stone-900 text-white shadow-2xs",
                      )}
                      variants={backVariants}
                      transition={sharedTransition}
                      style={{ transformOrigin: "center top" }}
                    >
                      <span className={cn("transition-colors shrink-0", item.iconColor)}>
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <span className="text-[11px] sm:text-xs font-medium tracking-normal whitespace-nowrap text-white">
                        {item.label}
                      </span>
                    </motion.div>
                  </motion.div>
                </button>
              </motion.li>
            );
          })}
        </ul>
      </motion.nav>
    );
  },
);

MenuBar.displayName = "MenuBar";

export default MenuBar;
