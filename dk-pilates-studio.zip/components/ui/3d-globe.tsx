export * from "../../src/components/ui/3d-globe";
export { default } from "../../src/components/ui/3d-globe";
