# DK Pilates Studio — Website Editorial Premium

Plataforma digital moderna, sofisticada e de alta conversão para o **DK Pilates Studio** (Jardim São Paulo, Zona Norte de São Paulo), com direção de arte editorial contemporânea em tons neutros aquecidos, arquitetura de componentes React modular e direcionamento direto ao WhatsApp oficial.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Decisões confirmadas pelo usuário:**
> - **Atmosfera Visual**: Estilo editorial refinado com neutros aquecidos (travertino/areia `#FAF8F5`, off-white `#F5F2EB`, papel quente `#EFECE6` e grafite escuro profundo `#18181B`).
> - **Apresentação de Modalidades**: Bento grid editorial destacando aparelhos autênticos (Reformer, Cadillac, Wunda Chair, Barrel) e o método clássico/funcional com rigor biomecânico.
> - **Conversão WhatsApp**: Botões diretos proeminentes e seletor rápido interativo de intenção (aula experimental, reabilitação/postural, horários, localização) que formata a mensagem e abre diretamente a conversa oficial (+55 11 97626-4452).

---

### 1. Overview & Core Concept

- **O que faz**: Apresenta com elegância a proposta e o espaço do DK Pilates Studio, seus diferenciais técnicos, equipamentos clássicos e estrutura física na Zona Norte de São Paulo, permitindo que potenciais alunos conheçam os benefícios para postura, força profunda e mobilidade, e iniciem atendimento imediato no WhatsApp.
- **Público-alvo**: Praticantes de Pilates, pessoas em busca de alívio de dores posturais/coluna, reabilitação física, condicionamento biomecânico e qualidade de vida na região de Santana, Jardim São Paulo e Zona Norte da capital paulista.
- **Proposta de Valor**: Uma experiência livre de clichês de academias genéricas, transmitindo serenidade, precisão clínica e bem-estar de alto padrão em cada detalhe tipográfico e espacial.

---

### 2. User Experience & Visual Design

#### Fluxo do Usuário
1. **Header Minimalista (Top Bar Contract de 3 Zonas)**:
   - Zona 1: Wordmark editorial `DK PILATES STUDIO`.
   - Zona 2: Links fluidos com scroll suave (`O Studio`, `Modalidades`, `Aparelhos`, `Espaço & Rotina`, `Localização`).
   - Zona 3: Botão de ação único de alto contraste: `Agendar Aula`.
2. **Hero Section Impactante**:
   - Título equilibrado com tipografia editorial elegante: *Movimento consciente, precisão postural e bem-estar profundo*.
   - Proposição de valor clara e sem jargões de marketing vazios.
   - Metadados discretos e desencaixotados (sem pills genéricas): *Jardim São Paulo · Zona Norte SP · Seg a Sex 06h às 22h*.
   - Ação primária destacada com link imediato para o WhatsApp oficial.
3. **Seção "O Estúdio & Filosofia"**:
   - Espaço acolhedor com atendimento individualizado e turmas reduzidas.
   - Foco em controle motor, fortalecimento do core, respiração e reeducação biomecânica.
4. **Bento Grid Editorial de Modalidades & Aparelhos**:
   - *Pilates Clássico & Studio*: Trabalho completo nos aparelhos clássicos (Cadillac, Reformer, Chair, Barrel).
   - *Pilates Funcional & Movimento*: Transferência para atividades diárias e ganho de estabilidade.
   - *Saúde da Coluna & Postura*: Foco em alívio de tensões crônicas e prevenção de lesões.
   - *Aparelhos Autênticos*: Cards visuais dedicados demonstrando os equipamentos de madeira nobre e molas calibradas.
5. **Seletor Rápido de Conversa para WhatsApp (Interactive Conversation Launcher)**:
   - Componente interativo refinado permitindo ao visitante escolher seu objetivo:
     - *Aula Experimental*
     - *Dores Posturais & Reabilitação*
     - *Condicionamento Físico & Mobilidade*
     - *Valores & Planos*
   - O visitante visualiza a mensagem pré-configurada elegante e clica em `Iniciar conversa no WhatsApp`.
6. **Espaço, Localização & Informações Reais Confirmadas**:
   - Endereço oficial confirmado: **Rua Gaspar Soares, 88 - Jardim São Paulo, São Paulo - SP**.
   - Horários de funcionamento reais: Segunda a Sexta (06h às 22h) e Sábado (08h às 12h).
   - Card interativo com botão direto para Google Maps e Waze.
7. **Perguntas Frequentes (FAQ)**:
   - Dúvidas reais: *Preciso ter experiência prévia?*, *Como funciona a aula experimental?*, *Quem tem dores na coluna pode praticar?*, *Qual a vestimenta recomendada?*.
8. **Rodapé Editorial**:
   - Identidade DK Pilates Studio, links institucionais, dados de contato e aviso de direitos reservados.

#### Identidade Visual & Tipografia
- **Paleta de Cores (Regra 60-30-10)**:
  - *60% Fundo Neutro Aquecido*: Travertino suave (`#FAF8F5`) e off-white linho (`#F5F2EB`).
  - *30% Superfícies & Estrutura*: Bordas ultrafinas em tom mineral (`#E5E0D8`), cartões em tom areia sedosa (`#FFFFFF` e `#FBF9F6`), textos secundários em ardósia quente (`#57534E`).
  - *10% Destaque*: Grafite escuro profundo (`#1C1917` / `#18181B`) e verde sábia botânico discreto (`#2D5A4C` / `#224237`) para elementos de ação e o ícone nativo do WhatsApp.
- **Tipografia**:
  - Títulos: Serifada editorial elegante (`Cormorant Garamond` / `Playfair Display`).
  - Texto corrido e controles: Sem serifa geométrica neutra e legível (`Plus Jakarta Sans` / `Outfit`).
  - Respeito integral a `prefers-reduced-motion` e zero pills artificiais.

---

### 3. Key Product Decisions & Trade-Offs

- **Sem Mock Data ou Depoimentos Falsos**:
  - *Decisão*: Restringir rigorosamente as informações às fontes públicas comprovadas em `SOURCES-AND-FACTS.md` (endereço, horários, modalidades, contato).
  - *Motivo*: Respeita a instrução expressa do usuário de não inventar depoimentos fictícios ou dados não confirmados.
- **Conversão via Seletor de Mensagem Dinâmico**:
  - *Decisão*: Criar um acionador de WhatsApp com opções predefinidas de interesse que gera o link codificado `https://wa.me/5511976264452?text=...`.
  - *Motivo*: Reduz a fricção do lead e garante que a equipe do estúdio já receba o contato qualificado com a necessidade do aluno.
- **Componentização React Pura e Leve**:
  - *Decisão*: Arquitetura de componentes reutilizáveis e estados limpos sem dependência de backend ou CMS pesado.
  - *Motivo*: Carregamento instantâneo, responsividade fluida para mobile/desktop e manutenção descomplicada.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                               App.tsx                                  │
│  (Theme Provider, Smooth Scroll, Reduced Motion Watcher, SEO Headers) │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
    ┌───────────────────────────────┼───────────────────────────────┐
    ▼                               ▼                               ▼
┌──────────────┐            ┌──────────────┐                ┌──────────────┐
│  Navbar.tsx  │            │   Hero.tsx   │                │  About.tsx   │
│ (3-Zone Bar, │            │ (Editorial,  │                │(Metodologia, │
│ Mobile Menu) │            │ Verified CTA)│                │ Biomecânica) │
└──────────────┘            └──────────────┘                └──────────────┘
    │                               │                               │
    ├───────────────────────────────┼───────────────────────────────┤
    ▼                               ▼                               ▼
┌──────────────┐            ┌──────────────┐                ┌──────────────┐
│  BentoGrid   │            │ WhatsAppCTA  │                │ LocationInfo │
│ (Modalidades,│            │(Quick Launch,│                │ (Horários,   │
│ Aparelhos)   │            │ Message Gen) │                │ Mapa, Waze)  │
└──────────────┘            └──────────────┘                └──────────────┘
    │                               │                               │
    └───────────────────────────────┴───────────────────────────────┘
                                    │
                                    ▼
                         ┌───────────────────────┐
                         │   FAQ & Footer.tsx    │
                         └───────────────────────┘
```

#### Estrutura de Estado & Interatividade
- `selectedModality`: Controle do foco interativo e detalhamento dos aparelhos.
- `quickMessageIntent`: Estado do seletor de mensagem pré-formatada para o WhatsApp.
- `mobileMenuOpen`: Controle da navegação expansível em dispositivos móveis.
- `faqOpenIndex`: Acordeom acessível com revelação suave e suporte a teclado.
- `prefersReducedMotion`: Hook nativo para desativar animações complexas quando solicitado pelo sistema do usuário.

---

### Ready for Execution

Após a aprovação deste plano, iniciaremos a execução imediatamente:
1. Geração em lote único das fotografias editoriais de Pilates e aparelhos via `generate_image`.
2. Implementação dos componentes modulares com Tailwind e tipografia refinada.
3. Teste completo de compilação, responsividade e validação dos links do WhatsApp.
